tar -xzvf simplesim-3.0-master.zip

cd simplesim-3.0-master/

make config-pisa

make


